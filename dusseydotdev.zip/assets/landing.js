const yearElement = document.getElementById("yr");
if (yearElement) {
  yearElement.textContent = new Date().getFullYear();
}